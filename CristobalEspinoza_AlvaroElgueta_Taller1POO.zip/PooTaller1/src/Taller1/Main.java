package Taller1;

// Cristóbal Espinoza - 21735612-1 ICCI
// Alvaro ELgueta - 21806097-8 ICCI

import java.io.File;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        // Sgtrings para guardar los datos del los archivos (los uso mediante un arreglo)
        
        
        String[] experimentos = leerArchivo("experimentos.txt", 10);
        String[] metricas = leerArchivo("metricas.txt", 10);
        String[] predicciones = leerArchivo("predicciones.txt", 200);
        
        if (experimentos == null || metricas == null || predicciones == null) {
            System.out.println("Error al cargar los archivos. Saliendo...");
            return;
        }
        
        do {
            System.out.println("\n=== SISTEMA DE METRICAS ML ===");
            System.out.println("1. Menu Administrador");
            System.out.println("2. Menu Usuario");
            System.out.println("3. Salir");
            System.out.print("Seleccione opcion: ");
            opcion = scanner.nextInt();
            
            switch(opcion) {
                case 1:
                    menuAdministrador(experimentos, predicciones);
                    break;
                case 2:
                    menuUsuario(experimentos, predicciones);
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
            
        } while(opcion != 3);
        
        scanner.close();
    }
    
    // menú de admin: 
    
    
    public static void menuAdministrador(String[] experimentos, String[] predicciones) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        do {
            System.out.println("\n=== MENU ADMINISTRADOR ===");
            
            System.out.println("1. Ver matriz completa de metricas");
            
            System.out.println("2. Identificar mejor F1-Score");
            
            System.out.println("3. Calcular promedios globales");
            
            System.out.println("4. Comparar dos experimentos");
            
            System.out.println("5. Volver al menu principal");
            
            System.out.print("Seleccione opcion: ");
            
            opcion = scanner.nextInt();
            
            // LLamo a las funciones (no quisimos hacer todo dentro de los case);
            
            switch(opcion) {
                case 1:
                    verMatrizCompleta(experimentos, predicciones);
                    break;
                case 2:
                    identificarMejorF1(experimentos, predicciones);
                    break;
                case 3:
                    calcularPromediosGlobales(experimentos, predicciones);
                    break;
                case 4:
                    compararExperimentos(experimentos, predicciones);
                    break;
                case 5:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
            
        } while(opcion != 5);
    }
    
    // menú de usuario
    
    public static void menuUsuario(String[] experimentos, String[] predicciones) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        do {
            System.out.println("\n=== MENU USUARIO ===");
            
            System.out.println("1. Ver lista de experimentos");
        
            System.out.println("2. Mostrar matriz de confusion");
            
            System.out.println("3. Ver metricas de experimento");
            
            System.out.println("4. Ver promedio de Accuracy");
            
            System.out.println("5. Volver al menu principal");
            
            System.out.print("Seleccione opcion: ");
            
            opcion = scanner.nextInt();
            
            // Switch case con cada opción: 
            
            switch(opcion) {
                case 1:
                    verListaExperimentos(experimentos);
                    break;
                case 2:
                    mostrarMatrizConfusion(experimentos, predicciones);
                    break;
                case 3:
                    verMetricasExperimento(experimentos, predicciones);
                    break;
                case 4:
                    verPromedioAccuracy(experimentos, predicciones);
                    break;
                case 5:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
            
        } while(opcion != 5);
    }
    
    // funciones del menu de admin: 
    
    // func para ver matriz completa de métricas :
    
    public static void verMatrizCompleta(String[] experimentos, String[] predicciones) {
        System.out.println("\n=== MATRIZ COMPLETA DE METRICAS ===");
        System.out.println("Experimento  Accuracy  Precision  Recall  F1-Score");
        System.out.println("--------------------------------------------------");
        
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                String id = partes[0];
                
                int[] matriz = calcularMatrizConfusion(id, predicciones);
                double accuracy = calcularAccuracy(matriz[0], matriz[1], matriz[2], matriz[3]);
                double precision = calcularPrecision(matriz[0], matriz[2]);
                double recall = calcularRecall(matriz[0], matriz[3]);
                double f1 = calcularF1(precision, recall);
                
                System.out.println(id + "         " + redondear(accuracy) + "     " + 
                                  redondear(precision) + "     " + redondear(recall) + 
                                  "     " + redondear(f1));
            }
        }
    }
    
    // 2. Identificar el experimento con mejor F1-Score (12 pts)
    public static void identificarMejorF1(String[] experimentos, String[] predicciones) {
        double mejorF1 = -1;
        String mejorExp = "";
        
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                String id = partes[0];
                
                int[] matriz = calcularMatrizConfusion(id, predicciones);
                double precision = calcularPrecision(matriz[0], matriz[2]);
                double recall = calcularRecall(matriz[0], matriz[3]);
                double f1 = calcularF1(precision, recall);
                
                if (f1 > mejorF1) {
                    mejorF1 = f1;
                    mejorExp = id + " - " + partes[1];
                }
            }
        }
        
        System.out.println("\nMejor F1-Score: " + redondear(mejorF1));
        System.out.println("Experimento: " + mejorExp);
    }
    
    // calc el promedio global de cada métrica
    
    public static void calcularPromediosGlobales(String[] experimentos, String[] predicciones) {
        double totalAccuracy = 0;
        double totalPrecision = 0;
        double totalRecall = 0;
        double totalF1 = 0;
        int contador = 0;
        
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                String id = partes[0];
                
                int[] matriz = calcularMatrizConfusion(id, predicciones);
                double accuracy = calcularAccuracy(matriz[0], matriz[1], matriz[2], matriz[3]);
                double precision = calcularPrecision(matriz[0], matriz[2]);
                double recall = calcularRecall(matriz[0], matriz[3]);
                double f1 = calcularF1(precision, recall);
                
                totalAccuracy += accuracy;
                totalPrecision += precision;
                totalRecall += recall;
                totalF1 += f1;
                contador++;
            }
        }
        
        System.out.println("\n=== PROMEDIOS GLOBALES ===");
        System.out.println("Accuracy promedio: " + redondear(totalAccuracy / contador));
        System.out.println("Precision promedio: " + redondear(totalPrecision / contador));
        System.out.println("Recall promedio: " + redondear(totalRecall / contador));
        System.out.println("F1-Score promedio: " + redondear(totalF1 / contador));
    }
    
    // comparar 2 experimentos : 
    
    public static void compararExperimentos(String[] experimentos, String[] predicciones) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("\nExperimentos disponibles:");
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                System.out.println(partes[0] + " - " + partes[1]);
            }
        }
        
        System.out.print("Ingrese primer experimento (Ej: Exp1): ");
        String exp1 = scanner.next();
        System.out.print("Ingrese segundo experimento (Ej: Exp2): ");
        String exp2 = scanner.next();
        
        int[] matriz1 = calcularMatrizConfusion(exp1, predicciones);
        int[] matriz2 = calcularMatrizConfusion(exp2, predicciones);
        
        System.out.println("\n=== COMPARACION: " + exp1 + " vs " + exp2 + " ===");
        System.out.println("Metrica         " + exp1 + "    " + exp2);
        System.out.println("-----------------------------");
        System.out.println("VP             " + matriz1[0] + "        " + matriz2[0]);
        System.out.println("VN             " + matriz1[1] + "        " + matriz2[1]);
        System.out.println("FP             " + matriz1[2] + "        " + matriz2[2]);
        System.out.println("FN             " + matriz1[3] + "        " + matriz2[3]);
        
        double acc1 = calcularAccuracy(matriz1[0], matriz1[1], matriz1[2], matriz1[3]);
        double acc2 = calcularAccuracy(matriz2[0], matriz2[1], matriz2[2], matriz2[3]);
        System.out.println("Accuracy       " + redondear(acc1) + "     " + redondear(acc2));
        
        double pre1 = calcularPrecision(matriz1[0], matriz1[2]);
        double pre2 = calcularPrecision(matriz2[0], matriz2[2]);
        System.out.println("Precision      " + redondear(pre1) + "     " + redondear(pre2));
        
        double rec1 = calcularRecall(matriz1[0], matriz1[3]);
        double rec2 = calcularRecall(matriz2[0], matriz2[3]);
        System.out.println("Recall         " + redondear(rec1) + "     " + redondear(rec2));
        
        double f1_1 = calcularF1(pre1, rec1);
        double f1_2 = calcularF1(pre2, rec2);
        System.out.println("F1-Score       " + redondear(f1_1) + "     " + redondear(f1_2));
    }
    
    // Funciones del menú de usuario: 
    
    // ver la lista de los experimentos : 
    
    
        public static void verListaExperimentos(String[] experimentos) {
        System.out.println("\n=== LISTA DE EXPERIMENTOS ===");
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                System.out.println(partes[0] + " - " + partes[1]);
            }
        }
    }
    
    // Mostrar conf de un experimento: 
        
    public static void mostrarMatrizConfusion(String[] experimentos, String[] predicciones) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese el experimento (Ej: Exp1): ");
        String exp = scanner.next();
        
        int[] matriz = calcularMatrizConfusion(exp, predicciones);
        
        System.out.println("\n=== MATRIZ DE CONFUSION: " + exp + " ===");
        System.out.println("Verdaderos Positivos (VP): " + matriz[0]);
        System.out.println("Verdaderos Negativos (VN): " + matriz[1]);
        System.out.println("Falsos Positivos (FP): " + matriz[2]);
        System.out.println("Falsos Negativos (FN): " + matriz[3]);
        System.out.println("Total: " + (matriz[0] + matriz[1] + matriz[2] + matriz[3]));
    }
    
    // Métricas de un experimento : 
    
    
    public static void verMetricasExperimento(String[] experimentos, String[] predicciones) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese el experimento (Ej: Exp1): ");
        String exp = scanner.next();
        
        int[] matriz = calcularMatrizConfusion(exp, predicciones);
        double accuracy = calcularAccuracy(matriz[0], matriz[1], matriz[2], matriz[3]);
        double precision = calcularPrecision(matriz[0], matriz[2]);
        double recall = calcularRecall(matriz[0], matriz[3]);
        double f1 = calcularF1(precision, recall);
        
        System.out.println("\n=== METRICAS: " + exp + " ===");
        System.out.println("Accuracy: " + redondear(accuracy));
        System.out.println("Precision: " + redondear(precision));
        System.out.println("Recall: " + redondear(recall));
        System.out.println("F1-Score: " + redondear(f1));
    }
    
    // Promedio de Accuracy de los experimentos: 
    
    
    public static void verPromedioAccuracy(String[] experimentos, String[] predicciones) {
        double totalAccuracy = 0;
        int contador = 0;
        
        for (String exp : experimentos) {
            if (exp != null) {
                String[] partes = exp.split(";");
                String id = partes[0];
                
                int[] matriz = calcularMatrizConfusion(id, predicciones);
                double accuracy = calcularAccuracy(matriz[0], matriz[1], matriz[2], matriz[3]);
                totalAccuracy += accuracy;
                contador++;
            }
        }
        
        System.out.println("\nPromedio de Accuracy: " + redondear(totalAccuracy / contador));
        System.out.println("Total de modelos: " + contador);
    }
    
    // Funciones aux: ( ya sean para leer archivo o simplificar otras cosas ):
    
    
    public static String[] leerArchivo(String nombreArchivo, int maxLineas) {
        String[] lineas = new String[maxLineas];
        int contador = 0;
        
        try {
            File archivo = new File(nombreArchivo);
            Scanner lector = new Scanner(archivo);
            
            while (lector.hasNextLine() && contador < maxLineas) {
                lineas[contador] = lector.nextLine();
                contador++;
            }
            lector.close();
            
        } catch (Exception e) {
            System.out.println("Error al leer: " + nombreArchivo);
            return null;
        }
        
        return lineas;
    }
    
    public static int[] calcularMatrizConfusion(String idExperimento, String[] predicciones) {
        int vp = 0, vn = 0, fp = 0, fn = 0;
        
        for (int i = 0; i < predicciones.length; i++) {
            if (predicciones[i] != null && predicciones[i].startsWith(idExperimento)) {
                String[] datos = predicciones[i].split(";");
                int real = Integer.parseInt(datos[1]);
                int prediccion = Integer.parseInt(datos[2]);
                
                if (real == 1 && prediccion == 1) vp++;
                else if (real == 0 && prediccion == 0) vn++;
                else if (real == 0 && prediccion == 1) fp++;
                else if (real == 1 && prediccion == 0) fn++;
            }
        }
        
        return new int[]{vp, vn, fp, fn};
    }
    
    public static double calcularAccuracy(int vp, int vn, int fp, int fn) {
        int total = vp + vn + fp + fn;
        if (total == 0) return 0;
        return (double)(vp + vn) / total;
    }
    
    public static double calcularPrecision(int vp, int fp) {
        if (vp + fp == 0) return 0;
        return (double)vp / (vp + fp);
    }
    
    public static double calcularRecall(int vp, int fn) {
        if (vp + fn == 0) return 0;
        return (double)vp / (vp + fn);
    }
    
    public static double calcularF1(double precision, double recall) {
        if (precision + recall == 0) return 0;
        return 2 * (precision * recall) / (precision + recall);
    }
    
    public static String redondear(double numero) {
    	
    	
        // Redondear a 3 decimales: 
    	
        int mientras = (int)(numero * 1000 + 0.5);
        double resultado = mientras / 1000.0;
        return String.valueOf(resultado);
    }
}